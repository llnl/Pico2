// Set directories
lowFamDir = "C:/Users/ng45/Downloads/FAM Data/";
coumarinDir = "C:/Users/ng45/Downloads/Coumarin Data/"; 
outputDir = "C:/Users/ng45/Downloads/Project_Series(1-53) (Low FAM Coumarin Overlap)/"; 

lowFamList = getFileList(lowFamDir);

setBatchMode(true);
run("Clear Results"); 

for (i = 0; i < lowFamList.length; i++) {
    if (endsWith(lowFamList[i], ".png")) {
        run("Close All");

        lowFamFile = lowFamList[i];
        coumarinFile = replace(lowFamFile, "ch01", "ch03"); 

        print("Processing Low FAM: " + lowFamDir + lowFamFile);
        print("Processing Coumarin: " + coumarinDir + coumarinFile);

        open(lowFamDir + lowFamFile);
        if (!isOpen(lowFamFile)) {
            print("Failed to open Low FAM image: " + lowFamFile);
            continue;
        }
        print("Opened Low FAM image.");

        run("8-bit");
        run("Duplicate...", "title=LowFAM");
        selectWindow("LowFAM");
        setThreshold(25, 45);
		run("Convert to Mask");
		run("Despeckle");
		run("Remove Outliers...", "radius=45 threshold=70 which=Bright");
		run("Median...", "radius=20");
		run("Fill Holes");
		run("Watershed");
        run("Duplicate...", "title=LowFAM_Mask");
        print("Low FAM mask created.");

        open(coumarinDir + coumarinFile);
        if (!isOpen(coumarinFile)) {
            print("Failed to open Coumarin image: " + coumarinFile);
            continue;
        }
        print("Opened Coumarin image.");

        run("8-bit");
        run("Duplicate...", "title=Coumarin");
        selectWindow("Coumarin");
        setThreshold(71, 255); // Adjust threshold for Coumarin
        run("Convert to Mask");
        run("Open");
		run("Close-");
        run("Median...", "radius=10");
        run("Watershed");
        run("Duplicate...", "title=Coumarin_Mask");
        print("Coumarin mask created.");

        // Debug: Print open windows before calculator
        list = getList("image.titles");
        print("Open windows before calculator:");
        Array.print(list);

        // Debug: Check if masks are open
        print("Is LowFAM_Mask open? " + isOpen("LowFAM_Mask"));
        print("Is Coumarin_Mask open? " + isOpen("Coumarin_Mask"));

        // Image calculator step
        imageCalculator("AND create", "LowFAM_Mask", "Coumarin_Mask");

        // Debug: Print open windows after calculator
        list = getList("image.titles");
        print("Open windows after calculator: ");
        Array.print(list);

        // Image calculator and overlap mask steps...

        if (isOpen("Result of LowFAM_Mask")) {
            selectWindow("Result of LowFAM_Mask");
            run("Despeckle");
            run("Median...", "radius=10");
            run("Watershed");

            saveAs("PNG", outputDir + "Overlap_" + substring(lowFamFile, 0, lengthOf(lowFamFile)-4) + ".png");

            run("Analyze Particles...", "size=2000-Infinity circularity=0.50-1.00 show=[Overlay Masks] display clear summarize add");
        }

        run("Close All");
    }
}

// Saving Results
saveAs("Results", outputDir + "Summary_Results.csv");
setBatchMode(false);