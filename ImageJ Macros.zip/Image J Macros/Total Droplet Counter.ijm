run("8-bit");
setThreshold(23, 255);
run("Convert to Mask");
run("Open");
run("Close-");
run("Median", "radius=10");
run("Watershed");
run("Analyze Particles...", "size=2000-Infinity show=[Overlay Masks] display clear summarize add");
