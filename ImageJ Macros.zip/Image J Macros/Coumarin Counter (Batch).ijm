run("8-bit");
setThreshold(71, 255);
run("Convert to Mask");
run("Open");
run("Close-");
run("Median", "radius=10");
run("Watershed");
run("Analyze Particles...", "size=1000-Infinity show=[Overlay Masks] display clear summarize add");
