path = File.openDialog("High FAM Image");
if (path != "") {
    // Open the selected image
    open(path);

//just to take name for ease of saving files
origName = getTitle();

dotIndex = lastIndexOf(origName, ".");
if (dotIndex != -1)
    baseName = substring(origName, 0, dotIndex);
else
    baseName = origName;

prefix = substring(baseName, 0, 2); //takes first 2 characters of file opened


rename("High");

path = File.openDialog("Coumarin Image");
if (path != "") {
    // Open the selected image
    open(path);

rename("Coumarin");

path = File.openDialog("Cy5 Image");
if (path != "") {
    // Open the selected image
    open(path);

rename("Cy5");

// Prep Masks for Overlap

selectImage("High");
run("8-bit");
setAutoThreshold("Default dark 16-bit no-reset");
//run("Threshold...");
setThreshold(1, 255, "raw");
//setThreshold(1, 255);
setOption("BlackBackground", true);
run("Convert to Mask");

selectImage("Coumarin");
run("8-bit");
setAutoThreshold("Default dark 16-bit no-reset");
//run("Threshold...");
setThreshold(1, 255, "raw");
//setThreshold(1, 255);
setOption("BlackBackground", true);
run("Convert to Mask");

selectImage("Cy5");
run("8-bit");
setAutoThreshold("Default dark 16-bit no-reset");
//run("Threshold...");
setThreshold(1, 255, "raw");
//setThreshold(1, 255);
setOption("BlackBackground", true);
run("Convert to Mask");

// Overlapping

imageCalculator("AND create", "Coumarin","Cy5");
selectImage("Result of Coumarin");
rename("CCy5");
run("Options...", "iterations=15 count=1 black do=Nothing");
run("Open");
run("Options...", "iterations=3 count=1 black do=Nothing");
run("Close-");
run("Watershed");

imageCalculator("AND create", "High","CCy5");
selectImage("Result of High");
rename("H Overlap");

imageCalculator("Subtract create", "High","CCy5");
selectImage("Result of High");
rename("H FAM Stray");

imageCalculator("Subtract create", "CCy5","High");
selectImage("Result of CCy5");
rename("CCy5 Stray");

// Analyze Overlap

selectImage("CCy5");
run("Analyze Particles...", "size=1500-10000 circularity=0.75-1.00 show=[Overlay Masks] display summarize");

selectImage("H Overlap");
run("Options...", "iterations=10 count=1 black do=Nothing");
run("Open");
run("Options...", "iterations=3 count=1 black do=Nothing");
run("Close-");
run("Watershed");
run("Analyze Particles...", "size=1000-10000 circularity=0.75-1.00 show=[Overlay Masks] display summarize");

selectImage("H FAM Stray");
run("Options...", "iterations=15 count=1 black do=Nothing");
run("Open");
run("Options...", "iterations=3 count=1 black do=Nothing");
run("Close-");
run("Watershed");
run("Analyze Particles...", "size=1500-10000 circularity=0.75-1.00 show=[Overlay Masks] display summarize");

selectImage("CCy5 Stray");
run("Options...", "iterations=15 count=1 black do=Nothing");
run("Open");
run("Options...", "iterations=3 count=1 black do=Nothing");
run("Close-");
run("Watershed");
run("Analyze Particles...", "size=1500-10000 circularity=0.75-1.00 show=[Overlay Masks] display summarize");

// Save Images

selectImage("CCy5");
outFolder = "C:/Users/waitkus1/Downloads/HF Overlaps/";  // <-- change this
newName_CCy5  = outFolder + prefix + " - CCy5.png";
saveAs("PNG", newName_CCy5);

selectImage("H Overlap");
outFolder = "C:/Users/waitkus1/Downloads/HF Overlaps/";  // <-- change this
newName_HO  = outFolder + prefix + " - HOverlap.png";
saveAs("PNG", newName_HO);

selectImage("H FAM Stray");
outFolder = "C:/Users/waitkus1/Downloads/HF Overlaps/";  // <-- change this
newName_HFStray  = outFolder + prefix + " - HFStray.png";
saveAs("PNG", newName_HFStray);

selectImage("CCy5 Stray");
outFolder = "C:/Users/waitkus1/Downloads/HF Overlaps/";  // <-- change this
newName_CCy5Stray  = outFolder + prefix + " - CCy5Stray.png";
saveAs("PNG", newName_CCy5Stray);

selectWindow("Summary");
outFolder = "C:/Users/waitkus1/Downloads/HF Overlaps/";  // <-- change this
newName_S  = outFolder + prefix + " - Table.txt";
saveAs("Text", newName_S);

// Close Images

selectImage("High");
run("Close");
selectImage("Coumarin");
run("Close");
selectImage("Cy5");
run("Close");
selectWindow("Results");
run("Close");