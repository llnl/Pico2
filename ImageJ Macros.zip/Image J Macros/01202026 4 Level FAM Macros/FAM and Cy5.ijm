path = File.openDialog("High FAM Image");
if (path != "") {
    // Open the selected image
    open(path);

//just to take name for ease of saving files
origName = getTitle();

dotIndex = lastIndexOf(origName, ".");
if (dotIndex != -1)
    baseName = substring(origName, 0, dotIndex);
else
    baseName = origName;

prefix = substring(baseName, 0, 2); //takes first 2 characters of file opened


rename("High");

path = File.openDialog("Med FAM Image");
if (path != "") {
    // Open the selected image
    open(path);

rename("Med");

path = File.openDialog("Low FAM Image");
if (path != "") {
    // Open the selected image
    open(path);

rename("Low");

path = File.openDialog("Cy5 Image");
if (path != "") {
    // Open the selected image
    open(path);

rename("Cy5");

// Prep Masks for overlap

selectImage("High");
run("8-bit");
setAutoThreshold("Default dark 16-bit no-reset");
//run("Threshold...");
setThreshold(1, 255, "raw");
//setThreshold(1, 255);
setOption("BlackBackground", true);
run("Convert to Mask");

selectImage("Med");
run("8-bit");
setAutoThreshold("Default dark 16-bit no-reset");
//run("Threshold...");
setThreshold(1, 255, "raw");
//setThreshold(1, 255);
setOption("BlackBackground", true);
run("Convert to Mask");

selectImage("Low");
run("8-bit");
setAutoThreshold("Default dark 16-bit no-reset");
//run("Threshold...");
setThreshold(1, 255, "raw");
//setThreshold(1, 255);
setOption("BlackBackground", true);
run("Convert to Mask");

selectImage("Cy5");
run("8-bit");
setAutoThreshold("Default dark 16-bit no-reset");
//run("Threshold...");
setThreshold(1, 255, "raw");
//setThreshold(1, 255);
setOption("BlackBackground", true);
run("Convert to Mask");

// Process Overlapping

imageCalculator("Add create", "High","Med");
selectImage("Result of High");
rename("HM FAM");

imageCalculator("Subtract create", "High","Cy5");
selectImage("Result of High");
rename("H FAM Stray");

imageCalculator("Subtract create", "Med","Cy5");
selectImage("Result of Med");
rename("M FAM Stray");

imageCalculator("Subtract create", "Cy5", "HM FAM");
selectImage("Result of Cy5");
rename("Cy5 Stray");

imageCalculator("XOR create", "Cy5", "HM FAM");
selectImage("Result of Cy5");
rename("Total Stray");

imageCalculator("AND create", "HM FAM","Cy5");
selectImage("Result of HM FAM");
rename("Overlap HMCy5");

imageCalculator("AND create", "Med","Cy5");
selectImage("Result of Med");
rename("Overlap MCy5");

imageCalculator("AND create", "Low","Cy5");
selectImage("Result of Low");
rename("Overlap LCy5");

// Overlap Counts

selectImage("Overlap HMCy5");
run("Options...", "iterations=15 count=1 black do=Nothing");
run("Open");
run("Options...", "iterations=3 count=1 black do=Nothing");
run("Close-");
run("Watershed");
run("Analyze Particles...", "size=2000-10000 circularity=0.50-1.00 show=[Overlay Masks] display summarize");

selectImage("Overlap MCy5");
run("Options...", "iterations=15 count=1 black do=Nothing");
run("Open");
run("Options...", "iterations=3 count=1 black do=Nothing");
run("Close-");
run("Watershed");
run("Analyze Particles...", "size=2000-10000 circularity=0.50-1.00 show=[Overlay Masks] display summarize");

selectImage("Overlap LCy5");
run("Options...", "iterations=15 count=1 black do=Nothing");
run("Open");
run("Options...", "iterations=3 count=1 black do=Nothing");
run("Close-");
run("Watershed");
run("Analyze Particles...", "size=2000-10000 circularity=0.50-1.00 show=[Overlay Masks] display summarize");

selectImage("H FAM Stray");
run("Options...", "iterations=15 count=1 black do=Nothing");
run("Open");
run("Options...", "iterations=3 count=1 black do=Nothing");
run("Close-");
run("Watershed");
run("Analyze Particles...", "size=2000-Infinity circularity=0.50-1.00 show=[Overlay Masks] display summarize");

selectImage("M FAM Stray");
run("Options...", "iterations=15 count=1 black do=Nothing");
run("Open");
run("Options...", "iterations=3 count=1 black do=Nothing");
run("Close-");
run("Watershed");
run("Analyze Particles...", "size=2000-Infinity circularity=0.50-1.00 show=[Overlay Masks] display summarize");

selectImage("Cy5 Stray");
run("Options...", "iterations=15 count=1 black do=Nothing");
run("Open");
run("Options...", "iterations=3 count=1 black do=Nothing");
run("Close-");
run("Watershed");
run("Analyze Particles...", "size=2000-Infinity circularity=0.50-1.00 show=[Overlay Masks] display summarize");

selectImage("Total Stray");
run("Options...", "iterations=15 count=1 black do=Nothing");
run("Open");
run("Options...", "iterations=3 count=1 black do=Nothing");
run("Close-");
run("Watershed");
run("Analyze Particles...", "size=2000-Infinity circularity=0.50-1.00 show=[Overlay Masks] display summarize");

waitForUser("Check: Image Cleanup State. Click OK to continue.");

// saving processed images
selectImage("Overlap HMCy5");
outFolder = "C:/Users/waitkus1/Downloads/Cy5 Overlap/";  // <-- change this
newName_HMC  = outFolder + prefix + " - HMCy5.png";
saveAs("PNG", newName_HMC);

selectImage("Overlap MCy5");
outFolder = "C:/Users/waitkus1/Downloads/Cy5 Overlap/";  // <-- change this
newName_MC  = outFolder + prefix + " - MCy5.png";
saveAs("PNG", newName_MC);

selectImage("Overlap LCy5");
outFolder = "C:/Users/waitkus1/Downloads/Cy5 Overlap/";  // <-- change this
newName_LC  = outFolder + prefix + " - LCy5.png";
saveAs("PNG", newName_LC);

selectImage("H FAM Stray");
outFolder = "C:/Users/waitkus1/Downloads/Cy5 Overlap/";  // <-- change this
newName_HFS  = outFolder + prefix + " - HF Stray.png";
saveAs("PNG", newName_HFS);

selectImage("M FAM Stray");
outFolder = "C:/Users/waitkus1/Downloads/Cy5 Overlap/";  // <-- change this
newName_MFS  = outFolder + prefix + " - MF Stray.png";
saveAs("PNG", newName_MFS);

selectImage("Cy5 Stray");
outFolder = "C:/Users/waitkus1/Downloads/Cy5 Overlap/";  // <-- change this
newName_CS  = outFolder + prefix + " - Cy5 Stray.png";
saveAs("PNG", newName_CS);

selectImage("Total Stray");
outFolder = "C:/Users/waitkus1/Downloads/Cy5 Overlap/";  // <-- change this
newName_CS  = outFolder + prefix + " - Total Stray.png";
saveAs("PNG", newName_CS);

selectWindow("Summary");
outFolder = "C:/Users/waitkus1/Downloads/Cy5 Overlap/";  // <-- change this
newName_S  = outFolder + prefix + " - Cy5 Table.txt";
saveAs("Text", newName_S);

//auto close windows
selectImage("High");
run("Close");
selectImage("Med");
run("Close");
selectImage("Low");
run("Close");
selectImage("Cy5");
run("Close");
selectImage("HM FAM");
run("Close");
selectWindow("Results");
run("Close");