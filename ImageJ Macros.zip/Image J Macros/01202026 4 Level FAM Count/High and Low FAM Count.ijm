// if (isOpen("*") == 0) {
  //      open();  // ask user to open an image
    //}
path = File.openDialog("Select a FAM image to open");
if (path != "") {
    // Open the selected image
    open(path);
    
rename("High");
run("Duplicate...", "title=Low");

selectImage("High");
run("8-bit");
setAutoThreshold("Default dark 16-bit no-reset");
run("Threshold...");
setThreshold(37, 255);
run("Convert to Mask");
run("Close");
run("Options...", "iterations=3 count=1 black do=Nothing");
run("Close-");
run("Options...", "iterations=10 count=1 black do=Nothing");
run("Open");
run("Watershed");
run("Analyze Particles...", "size=800-15000 circularity=0.50-1.00 show=[Overlay Masks] display summarize");

selectImage("Low");
run("8-bit");
setAutoThreshold("Default dark 16-bit no-reset");
run("Threshold...");
setThreshold(7, 17);
run("Convert to Mask");
run("Close");
run("Options...", "iterations=3 count=1 black do=Nothing");
run("Close-");
run("Options...", "iterations=10 count=1 black do=Nothing");
run("Open");
run("Watershed");
run("Analyze Particles...", "size=1000-20000 circularity=0.50-1.00 show=[Overlay Masks] display summarize");