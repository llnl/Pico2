 if (isOpen("*") == 0) {
        open();  // ask user to open an image
    }
    
run("8-bit");
setAutoThreshold("Default dark 16-bit no-reset");
run("Threshold...");
setThreshold(76, 255);
setOption("BlackBackground", true);
run("Convert to Mask");
run("Close");
run("Options...", "iterations=1 count=1 black do=Nothing");
run("Open");
run("Close-");
run("Watershed");
//setTool("rectangle");
makeRectangle(54, 1503, 368, 6);
run("Colors...", "foreground=black background=black selection=yellow");
setForegroundColor(0, 0, 0);
run("Fill", "slice");
run("Select None");
run("Analyze Particles...", "size=1000-20000 circularity=0.50-1.00 show=[Overlay Masks] display summarize");
