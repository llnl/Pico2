 if (isOpen("*") == 0) {
        open();  // ask user to open an image
    }
    
run("8-bit");
setAutoThreshold("Default dark 16-bit no-reset");
run("Threshold...");
setThreshold(7, 17);
run("Convert to Mask");
run("Close");
run("Options...", "iterations=3 count=1 black do=Nothing");
run("Close-");
run("Options...", "iterations=10 count=1 black do=Nothing");
run("Open");
run("Watershed");
run("Analyze Particles...", "size=1000-20000 circularity=0.50-1.00 show=[Overlay Masks] display summarize");