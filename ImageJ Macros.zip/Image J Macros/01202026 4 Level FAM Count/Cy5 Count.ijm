 if (isOpen("*") == 0) {
        open();  // ask user to open an image
    }
    
//just to take name for ease of saving files
origName = getTitle();

dotIndex = lastIndexOf(origName, ".");
if (dotIndex != -1)
    baseName = substring(origName, 0, dotIndex);
else
    baseName = origName;

prefix = substring(baseName, 0, 2); //takes first 2 characters of file opened

run("Duplicate...", " ");
rename("Cy5");

//cover scale bar
makeRectangle(54, 1503, 368, 6);
run("Colors...", "foreground=black background=black selection=yellow");
setForegroundColor(0, 0, 0);
run("Fill", "slice");
run("Select None");

//count all droplets
run("8-bit");
setAutoThreshold("Default dark 16-bit no-reset");
run("Threshold...");
setThreshold(25, 255);
run("Convert to Mask");
run("Close");
run("Options...", "iterations=3 count=1 black do=Nothing");
run("Close-");
run("Options...", "iterations=5 count=1 black do=Nothing");
run("Open");
run("Watershed");
run("Analyze Particles...", "size=2000-15000 circularity=0.5-1.00 show=[Overlay Masks] display summarize");

//save image and summary table
selectImage("Cy5");
outFolder = "C:/Users/waitkus1/Downloads/Cy5 Processed/";  // <-- change this
newName_CS  = outFolder + prefix + " - Cy5.png";
saveAs("PNG", newName_CS);

selectWindow("Summary");
outFolder = "C:/Users/waitkus1/Downloads/Cy5 Processed/";  // <-- change this
newName_S  = outFolder + prefix + " - Table.txt";
saveAs("Text", newName_S);

//close window
selectWindow("Results");
run("Close");