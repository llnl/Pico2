path = File.openDialog("High FAM Image");
if (path != "") {
    // Open the selected image
    open(path);

//just to take name for ease of saving files
origName = getTitle();

dotIndex = lastIndexOf(origName, ".");
if (dotIndex != -1)
    baseName = substring(origName, 0, dotIndex);
else
    baseName = origName;

prefix = substring(baseName, 0, 2); //takes first 2 characters of file opened


rename("High");

path = File.openDialog("Med FAM Image");
if (path != "") {
    // Open the selected image
    open(path);

rename("Med");

path = File.openDialog("Low FAM Image");
if (path != "") {
    // Open the selected image
    open(path);

rename("Low");

path = File.openDialog("Coumarin Image");
if (path != "") {
    // Open the selected image
    open(path);

rename("Coumarin");

// Prep Masks for overlap

selectImage("High");
run("8-bit");
setAutoThreshold("Default dark 16-bit no-reset");
//run("Threshold...");
setThreshold(1, 255, "raw");
//setThreshold(1, 255);
setOption("BlackBackground", true);
run("Convert to Mask");

selectImage("Med");
run("8-bit");
setAutoThreshold("Default dark 16-bit no-reset");
//run("Threshold...");
setThreshold(1, 255, "raw");
//setThreshold(1, 255);
setOption("BlackBackground", true);
run("Convert to Mask");

selectImage("Low");
run("8-bit");
setAutoThreshold("Default dark 16-bit no-reset");
//run("Threshold...");
setThreshold(1, 255, "raw");
//setThreshold(1, 255);
setOption("BlackBackground", true);
run("Convert to Mask");

selectImage("Coumarin");
run("8-bit");
setAutoThreshold("Default dark 16-bit no-reset");
//run("Threshold...");
setThreshold(1, 255, "raw");
//setThreshold(1, 255);
setOption("BlackBackground", true);
run("Convert to Mask");


// Process Overlapping

imageCalculator("Add create", "High","Low");
selectImage("Result of High");
rename("HL FAM");

imageCalculator("Subtract create", "High","Coumarin");
selectImage("Result of High");
rename("H FAM Stray");

imageCalculator("Subtract create", "Low","Coumarin");
selectImage("Result of Low");
rename("L FAM Stray");

imageCalculator("Subtract create", "Coumarin", "HL FAM");
selectImage("Result of Coumarin");
rename("Coumarin Stray");

imageCalculator("AND create", "HL FAM","Coumarin");
selectImage("Result of HL FAM");
rename("Overlap HLC");

imageCalculator("AND create", "Low","Coumarin");
selectImage("Result of Low");
rename("Overlap LC");

imageCalculator("AND create", "Med","Coumarin");
selectImage("Result of Med");
rename("Overlap MC");

// Overlap Counts

selectImage("Overlap HLC");
run("Options...", "iterations=5 count=1 black do=Nothing");
run("Open");
run("Watershed");
run("Analyze Particles...", "size=1000-10000 circularity=0.00-1.00 show=[Overlay Masks] display summarize");

selectImage("Overlap MC");
run("Options...", "iterations=3 count=1 black do=Nothing");
run("Close-");
run("Options...", "iterations=10 count=1 black do=Nothing");
run("Open");
run("Watershed");
run("Analyze Particles...", "size=2500-10000 circularity=0.75-1.00 show=[Overlay Masks] display summarize");

selectImage("Overlap LC");
run("Options...", "iterations=5 count=1 black do=Nothing");
run("Open");
run("Watershed");
run("Analyze Particles...", "size=1000-Infinity circularity=0.00-1.00 show=[Overlay Masks] display summarize");

selectImage("H FAM Stray");
run("Options...", "iterations=3 count=1 black do=Nothing");
run("Close-");
run("Options...", "iterations=10 count=1 black do=Nothing");
run("Open");
run("Watershed");
run("Analyze Particles...", "size=1000-Infinity circularity=0.00-1.00 show=[Overlay Masks] display summarize");

selectImage("L FAM Stray");
run("Options...", "iterations=3 count=1 black do=Nothing");
run("Close-");
run("Options...", "iterations=10 count=1 black do=Nothing");
run("Open");
run("Watershed");
run("Analyze Particles...", "size=1000-Infinity circularity=0.00-1.00 show=[Overlay Masks] display summarize");

selectImage("Coumarin Stray");
run("Options...", "iterations=3 count=1 black do=Nothing");
run("Close-");
run("Options...", "iterations=10 count=1 black do=Nothing");
run("Open");
run("Watershed");
run("Analyze Particles...", "size=5000-Infinity circularity=0.00-1.00 show=[Overlay Masks] display summarize");

// saving processed images
selectImage("Overlap HLC");
outFolder = "C:/Users/waitkus1/Downloads/C Overlap/";  // <-- change this
newName_HLC  = outFolder + prefix + " - HLC.png";
saveAs("PNG", newName_HLC);

selectImage("Overlap MC");
outFolder = "C:/Users/waitkus1/Downloads/C Overlap/";  // <-- change this
newName_MC  = outFolder + prefix + " - MC.png";
saveAs("PNG", newName_MC);

selectImage("Overlap LC");
outFolder = "C:/Users/waitkus1/Downloads/C Overlap/";  // <-- change this
newName_LC  = outFolder + prefix + " - LC.png";
saveAs("PNG", newName_LC);

selectImage("H FAM Stray");
outFolder = "C:/Users/waitkus1/Downloads/C Overlap/";  // <-- change this
newName_HFS  = outFolder + prefix + " - HF Stray.png";
saveAs("PNG", newName_HFS);

selectImage("L FAM Stray");
outFolder = "C:/Users/waitkus1/Downloads/C Overlap/";  // <-- change this
newName_LFS  = outFolder + prefix + " - LF Stray.png";
saveAs("PNG", newName_LFS);

selectImage("Coumarin Stray");
outFolder = "C:/Users/waitkus1/Downloads/C Overlap/";  // <-- change this
newName_CS  = outFolder + prefix + " - C Stray.png";
saveAs("PNG", newName_CS);

selectWindow("Summary");
outFolder = "C:/Users/waitkus1/Downloads/C Overlap/";  // <-- change this
newName_S  = outFolder + prefix + " - C Table.txt";
saveAs("Text", newName_S);
