path = File.openDialog("Select a FAM image to open");
if (path != "") {
    // Open the selected image
    open(path);

//just to take name for ease of saving files
origName = getTitle();

dotIndex = lastIndexOf(origName, ".");
if (dotIndex != -1)
    baseName = substring(origName, 0, dotIndex);
else
    baseName = origName;

prefix = substring(baseName, 0, 4); //takes first 4 characters of file opened

// start of counting three FAM levels

rename("FAM");
run("Duplicate...", "title=High");
run("Duplicate...", "title=Med");
run("Duplicate...", "title=Low");

selectImage("High");
run("8-bit");
setAutoThreshold("Default dark 16-bit no-reset");
run("Threshold...");
setThreshold(48, 255);
run("Convert to Mask");
run("Close");
run("Options...", "iterations=3 count=1 black do=Nothing");
run("Close-");
run("Options...", "iterations=10 count=1 black do=Nothing");
run("Open");
run("Watershed");
run("Analyze Particles...", "size=1000-15000 circularity=0.50-1.00 show=[Overlay Masks] display summarize");

selectImage("Med");
run("8-bit");
setAutoThreshold("Default dark 16-bit no-reset");
run("Threshold...");
setThreshold(18, 50);
run("Convert to Mask");run("Close");
run("Options...", "iterations=3 count=1 black do=Nothing");
run("Close-");
run("Options...", "iterations=20 count=1 black do=Nothing");
run("Open");
run("Watershed");
run("Analyze Particles...", "size=2000-15000 circularity=0.75-1.00 show=[Overlay Masks] display summarize");

selectImage("Low");
run("8-bit");
setAutoThreshold("Default dark 16-bit no-reset");
run("Threshold...");
setThreshold(7, 21);
run("Convert to Mask");
run("Close");
run("Options...", "iterations=3 count=1 black do=Nothing");
run("Close-");
run("Options...", "iterations=10 count=1 black do=Nothing");
run("Open");
run("Watershed");
run("Analyze Particles...", "size=1500-20000 circularity=0.50-1.00 show=[Overlay Masks] display summarize");

// saving processed images
selectImage("High");
outFolder_H = "C:/Users/waitkus1/Downloads/01-14-2026 FAM Counted/";  // <-- change this
newName_H  = outFolder_H + prefix + " - High.png";
saveAs("PNG", newName_H);

selectImage("Med");
outFolder_M = "C:/Users/waitkus1/Downloads/01-14-2026 FAM Counted/";  // <-- change this
newName_M  = outFolder_M + prefix + " - Med.png";
saveAs("PNG", newName_M);

selectImage("Low");
outFolder_L = "C:/Users/waitkus1/Downloads/01-14-2026 FAM Counted/";  // <-- change this
newName_L  = outFolder_L + prefix + " - Low.png";
saveAs("PNG", newName_L);

selectWindow("Summary");
outFolder_S = "C:/Users/waitkus1/Downloads/01-14-2026 FAM Data/";  // <-- change this
newName_S  = outFolder_S + prefix + " - Table.png";
saveAs("Text", newName_S);

selectImage("FAM");
run("Out [-]");