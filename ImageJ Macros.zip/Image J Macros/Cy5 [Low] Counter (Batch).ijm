run("8-bit");
run("Brightness/Contrast...");
setMinAndMax(0, 78);
call("ij.ImagePlus.setDefault16bitRange", 8);
run("Apply LUT");
run("Close");
run("Threshold...");
setThreshold(53, 205);
setOption("BlackBackground", true);
run("Convert to Mask");
run("Close");
run("Options...", "iterations=1 count=1 black do=Nothing");
run("Close-");
run("Options...", "iterations=10 count=1 black do=Nothing");
run("Open");
run("Watershed");

run("Analyze Particles...", 
    "size=2000-20000 circularity=0.60-1.00 show=[Overlay Masks] display summarize");
