// Convert to 8-bit
run("8-bit");

// Duplicate original for Cy5
run("Duplicate...", "title=Cy5");

// Cy5 Count
selectWindow("Cy5");
setThreshold(20, 255);
run("Convert to Mask");
run("Open");
run("Close-");
run("Median", "radius=10");
run("Watershed");
run("Analyze Particles...", "size=2000-Infinity show=[Overlay Masks] display clear summarize add");
