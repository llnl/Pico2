// Convert to 8-bit
run("8-bit");

// Duplicate original for Coumarin
run("Duplicate...", "title=Coumarin");

// Coumarin Count
selectWindow("Coumarin");
setThreshold(10, 255);
run("Convert to Mask");
run("Open");
run("Close-");
run("Median", "radius=10");
run("Watershed");
run("Analyze Particles...", "size=2000-Infinity show=[Overlay Masks] display clear summarize add");
