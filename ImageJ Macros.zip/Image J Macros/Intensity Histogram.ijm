path = File.openDialog("Select a FAM image to open");
if (path != "") {
    // Open the selected image
    open(path);

rename("FAM");
run("Duplicate...", "title=BW Green");

run("Split Channels");
selectImage("BW (blue)");
close;
selectImage("BW (red)");
close;

selectImage("BW (green)");
run("Duplicate...", " ");
run("8-bit");
setAutoThreshold("Default dark 16-bit no-reset");
run("Threshold...");
setThreshold(20, 255);
setOption("BlackBackground", true);
run("Convert to Mask");
run("Close");

run("Set Measurements...", "area mean min integrated redirect=None decimal=3");
run("Options...", "iterations=10 count=1 black do=Nothing");
run("Open");
run("Watershed");
run("Analyze Particles...", "size=1500-20000 circularity=0.50-1.00 show=[Overlay Masks] summarize add composite");

selectImage("BW (green)");
run("Select All");
roiManager("Measure");
run("Distribution...", "parameter=Mean or=51 and=0-255");