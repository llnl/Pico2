run("8-bit");
setThreshold(25, 45);
run("Convert to Mask");
run("Despeckle");
run("Remove Outliers...", "radius=45 threshold=70 which=Bright");
run("Median...", "radius=20");
run("Fill Holes");
run("Watershed");
run("Analyze Particles...", "size=2000-Infinity circularity=0.50-1.00 show=[Overlay Masks] display clear summarize add");