// Set directories
famDir = "C:/Users/ng45/Downloads/FAM Data/";
cy5Dir = "C:/Users/ng45/Downloads/Cy5 Data/";
outputDir = "C:/Users/ng45/Downloads/Project_Series(1-53) (High FAM Cy5 Overlap)/";


famList = getFileList(famDir);

setBatchMode(true);
run("Clear Results"); 

for (i = 0; i < famList.length; i++) {
    if (endsWith(famList[i], ".png")) {
        run("Close All");

        famFile = famList[i];
        cy5File = replace(famFile, "ch01", "ch02");

                print("Processing FAM: " + famDir + famFile);
        print("Processing Cy5: " + cy5Dir + cy5File);

        open(famDir + famFile);
        if (!isOpen(famFile)) {
            print("Failed to open FAM image: " + famFile);
            continue;
        }
        print("Opened FAM image.");

        run("8-bit");
        run("Duplicate...", "title=FAM");
        selectWindow("FAM");
        setThreshold(53, 255);
        run("Convert to Mask");
        run("Despeckle");
        run("Median...", "radius=20");
        run("Watershed");
        run("Duplicate...", "title=FAM_Mask");
        print("FAM mask created.");

        open(cy5Dir + cy5File);
        if (!isOpen(cy5File)) {
            print("Failed to open Cy5 image: " + cy5File);
            continue;
        }
        print("Opened Cy5 image.");

        run("8-bit");
        run("Duplicate...", "title=Cy5");
        selectWindow("Cy5");
        setThreshold(30, 255);
        run("Convert to Mask");
        run("Open");
        run("Close-");
        run("Median...", "radius=15");
        run("Watershed");
        run("Duplicate...", "title=Cy5_Mask");
        print("Cy5 mask created.");

        // Debug: Print open windows before calculator
        list = getList("image.titles");
        print("Open windows before calculator:");
		Array.print(list);

        // Debug: Check if masks are open
        print("Is FAM_Mask open? " + isOpen("FAM_Mask"));
        print("Is Cy5_Mask open? " + isOpen("Cy5_Mask"));

		// Image calculator step
		imageCalculator("AND create", "FAM_Mask", "Cy5_Mask");

		// Debug: Print open windows after calculator
		list = getList("image.titles");
		print("Open windows after calculator: ");
		Array.print(list);

        // Image calculator and overlap mask steps...

        if (isOpen("Result of FAM_Mask")) {
            selectWindow("Result of FAM_Mask");
            run("Despeckle");
            run("Median...", "radius=10");
            run("Watershed");

            saveAs("PNG", outputDir + "Overlap_" + substring(famFile, 0, lengthOf(famFile)-4) + ".png");

            run("Analyze Particles...", "size=1000-Infinity show=[Overlay Masks] display clear summarize add");
   
        }

        run("Close All");
    }
}

// Step 4: Save all results at once
saveAs("Results", outputDir + "Summary_Results.csv");
setBatchMode(false);