run("8-bit");
setThreshold(53 255); 
run("Convert to Mask");
run("Despeckle");
run("Median...", "radius=20");
run("Watershed");
run("Analyze Particles...", "size=2000-Infinity show=[Overlay Masks] display clear summarize");