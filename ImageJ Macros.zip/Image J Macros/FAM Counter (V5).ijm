// Convert to 8-bit
run("8-bit");

// Duplicate original for High and Low FAM
run("Duplicate...", "title=High_FAM");
run("Duplicate...", "title=Low_FAM");

// High FAM Droplets 
selectWindow("High_FAM");
setThreshold(120, 255); 
run("Convert to Mask");
run("Despeckle");
run("Median...", "radius=10");
run("Watershed");
run("Analyze Particles...", "size=1000-Infinity show=[Overlay Masks] display clear summarize");

// Low FAM Droplets 
selectWindow("Low_FAM");
setThreshold(63, 135);
run("Convert to Mask");
run("Despeckle");
run("Median...", "radius=15");
run("Fill Holes");
run("Watershed");
run("Analyze Particles...", "size=1000-Infinity show=[Overlay Masks] display clear summarize");